# Ant Design 设计Token（模板）

> 基于 Ant Design 5.x 默认主题，需根据实际项目调整。

## 颜色

### 主色系
| Token名称 | 值 | 说明 |
|----------|-----|------|
| color.primary | #1677FF | 品牌色 |
| color.primary.hover | #4096FF | 悬停 |
| color.primary.active | #0958D9 | 按下 |

### 功能色
| Token名称 | 值 | 说明 |
|----------|-----|------|
| color.success | #52C41A | 成功 |
| color.success.bg | #F6FFED | 成功背景 |
| color.warning | #FAAD14 | 警告 |
| color.error | #FF4D4F | 错误 |
| color.error.bg | #FFF2F0 | 错误背景 |
| color.info | #1677FF | 信息 |
| color.info.bg | #E6F4FF | 信息背景 |

### 中性色
| Token名称 | 值 | 说明 |
|----------|-----|------|
| color.text.primary | rgba(0,0,0,0.88) | 标题、正文 |
| color.text.secondary | rgba(0,0,0,0.65) | 辅助信息 |
| color.text.placeholder | rgba(0,0,0,0.25) | 占位符 |
| color.border | #D9D9D9 | 边框 |
| color.bg.page | #F5F5F5 | 页面背景 |
| color.bg.card | #FFFFFF | 卡片背景 |
| color.bg.table-header | #FAFAFA | 表头背景 |

## 字体

| Token名称 | 值 |
|----------|-----|
| font.heading | -apple-system, BlinkMacSystemFont, Segoe UI |
| font.body | 同上 |
| font.size.h1 | 20px |
| font.size.h2 | 16px |
| font.size.body | 14px |
| font.size.small | 12px |

## 间距

| Token名称 | 值 |
|----------|-----|
| spacing.xs | 4px |
| spacing.sm | 8px |
| spacing.md | 12px |
| spacing.lg | 16px |
| spacing.xl | 24px |

## 圆角

| Token名称 | 值 |
|----------|-----|
| radius.card | 8px |
| radius.button | 6px |
| radius.input | 6px |
| radius.badge | 4px |
| radius.modal | 8px |

## 尺寸

| Token名称 | 值 |
|----------|-----|
| size.button-height | 32px |
| size.input-height | 32px |
| size.table-row-height | 54px |
| size.modal-width.sm | 520px |
| size.modal-width.md | 720px |
