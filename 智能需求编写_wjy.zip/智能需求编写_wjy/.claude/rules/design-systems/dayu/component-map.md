# 大禹组件库映射配置

## 组件库信息

| 配置项 | 值 |
|-------|-----|
| 组件库名称 | 大禹平台设计系统 |
| 组件库文件 | `/Users/wangjunyi/Desktop/工作/设计/dayu_platform.lib.pen` |
| 版本 | v1.3 |
| 更新日期 | 2026-04-02 |
| 变更说明 | 全面对齐线上 Element Plus 实际样式：主色 #409EFF、按钮 24px/3px 圆角、输入框 32px/4px 圆角、弹窗 2px 圆角/700px 宽、侧边栏 200px/#2E363F、导航 44px、菜单高亮橙色 #FB9100、字体改为系统字体栈 |

---

## 布局模板

| 语义名称 | 组件ID | 说明 |
|---------|--------|------|
| layout.list-page | MtsyV | 暗色侧边栏列表页布局（1440×900） |
| layout.form-page | VEdnN | 基础表单页模板 |
| layout.detail-page | yAaL5 | 基础详情页模板 |
| layout.modal | dFJUk | 模态弹窗（标题+内容+按钮） |
| layout.popconfirm-danger | APXcE | 危险确认气泡框（红色） |
| layout.popconfirm-default | wR118 | 普通确认气泡框 |

## 按钮

| 语义名称 | 组件ID | 说明 |
|---------|--------|------|
| button.primary | vgq7o | 主按钮（蓝色背景+白色文字） |
| button.primary.inner | ScGci | 主按钮内层容器 |
| button.primary.text | dx70O | 主按钮文字节点 |
| button.secondary | 9dyes | 次要按钮（白色背景+灰色边框） |
| button.secondary.inner | vbpdh | 次要按钮内层容器 |
| button.secondary.text | uU8Jp | 次要按钮文字节点 |
| button.danger | 1q9tS | 危险按钮（红色背景+白色文字） |
| button.text | xbQOZ | 文字按钮（蓝色文字） |

## 表单控件

| 语义名称 | 组件ID | 说明 |
|---------|--------|------|
| input.search | Ho7FQ | 搜索输入框 |
| input.text | 4tWeW | 普通输入框 |
| input.group | 0EFbf | 输入框组 |
| input.select | oYQgo | 下拉选择框 |
| input.select.text | vfJdh | 下拉选择框文字节点 |
| input.select-group | e3aUV | 下拉选择组 |
| input.date | GaOYi | 日期选择器 |
| input.date-range | cUGUg | 日期范围选择器 |
| input.time | jht4U | 时间选择器 |
| input.textarea-group | 7yQC8 | 多行文本组 |
| input.number | yAEPB | 数字输入框 |
| input.switch | tDCB8 | 开关 |
| input.checkbox | Gzx1a | 复选框 |
| input.radio-group | teRid | 单选组 |
| input.segmented | cvhYT | 分段控制器 |
| input.upload | pPR4L | 上传按钮 |
| form.field-row | MPDR9 | 表单字段行（标签+必填标记+输入框） |
| form.field-row.label | yaTgP | 表单字段行标签文字 |
| form.field-row.required | RXkpt | 表单字段行必填标记 |
| form.field-row.input | nUr5s | 表单字段行输入框插槽 |

## 数据展示

| 语义名称 | 组件ID | 说明 |
|---------|--------|------|
| table | qEg7Q | 表格 |
| table.head | hF28e | 表头行 |
| table.row | jtZCo | 数据行 |
| pagination | cDHCZ | 分页器 |
| pagination.info | DXH4k | 分页总数文字 |
| detail.field-row | 66UDp | 详情字段行（标签+只读值） |
| detail.field-row.label | vwa9U | 详情字段行标签 |
| detail.field-row.value | EtDlz | 详情字段行值 |
| section-card | a2hbf | 信息区块卡片（标题+内容插槽） |
| section-card.title | J4mAc | 区块标题 |
| section-card.content | Y3Og2 | 区块内容插槽 |
| list-action-bar | 1VBoa | 列表操作栏（"常用功能："+按钮） |
| statistic-card | LFVpr | 统计指标卡片（名称+数值+趋势） |
| statistic-card.label | LJhQT | 指标名称 |
| statistic-card.value | ZEfjS | 指标数值 |
| statistic-card.trend-arrow | AoI4Y | 趋势箭头 |
| statistic-card.trend-text | joRgy | 趋势文字 |
| chart-card | nMnRE | 图表区块卡片（标题+图表占位） |
| chart-card.title | Zvg2H | 图表标题 |
| chart-card.placeholder | Mzhbe | 图表占位文字 |
| editable-table-row | L08Nc | 可编辑表格行 |

## 状态徽章

| 语义名称 | 组件ID | 文字节点ID | 说明 |
|---------|--------|-----------|------|
| badge.primary | jZOqB | arYS2 | 主色徽章（蓝色） |
| badge.success | U1uq6 | xt2gY | 成功徽章（绿色） |
| badge.warning | izQXf | DVDyn | 警告徽章（橙色） |
| badge.error | BlNHw | sy1oA | 错误徽章（红色） |
| tag.success | XzL7y | - | 成功标签 |
| tag.warning | wqIrz | - | 警告标签 |
| tag.error | 2iFA4 | - | 错误标签 |

## 反馈组件

| 语义名称 | 组件ID | 说明 |
|---------|--------|------|
| alert.success | ubb8A | 成功提示 |
| alert.warning | CMlxR | 警告提示 |
| alert.error | ja1Sv | 错误提示 |
| alert.info | LMtPJ | 信息提示 |
| message.success | HHIXt | 成功消息 |
| message.error | Idyto | 错误消息 |
| result.success | km8ef | 成功结果卡片 |
| result.failure | EseHw | 失败结果卡片 |
| empty | ORTsb | 空状态 |
| skeleton.card | HhP7J | 骨架屏卡片 |
| skeleton.list | DQAov | 骨架屏列表 |

## 状态关键词映射

| 状态关键词 | 语义名称 |
|----------|---------|
| 正常/运行中/active/启用/达标 | badge.success |
| 异常/停止/inactive/禁用/不达标 | badge.error |
| 待处理/pending/警告/处理中 | badge.primary |

## 按钮样式推断

| 操作关键词 | 语义名称 |
|----------|---------|
| 新建/创建/添加 | button.primary |
| 导出/导入/刷新/重置 | button.secondary |
| 删除/移除 | button.danger 或红色文字 |
| 编辑/修改/查看 | 蓝色文字链接 |

## 列表页增强组件

| 语义名称 | 组件ID | 说明 |
|---------|--------|------|
| table.checkbox | URFcn | 表格复选框（未选/选中/半选三态） |
| filter.environment | 4VcxM | 环境筛选条（全部/DEV/FAT/UAT/PROD pill按钮组） |
| filter.status | dPatp | 事件状态筛选（全部/触发/恢复 pill按钮组） |

## 通用交互组件

| 语义名称 | 组件ID | 说明 |
|---------|--------|------|
| sidebar.collapse | JTE3V | 侧边栏折叠按钮 |
| user.dropdown | CSIuY | 用户下拉菜单（头像+用户名+箭头） |
| table.loading | DhV1P | 表格Loading遮罩（半透明+旋转图标） |
| transfer | AmtyC | 穿梭框（双栏选择器） |

## Dashboard 首页组件

| 语义名称 | 组件ID | 说明 |
|---------|--------|------|
| dashboard.asset-card | aRpD9 | 资产统计卡片（图标+标签+数字） |
| dashboard.alert-card | o0IdM | 告警摘要卡片（警告图标+标签+数字） |
| dashboard.donut-chart | hXHDO | 环形图（甜甜圈图+中心数字） |
| dashboard.side-panel | spfKx | 右侧面板（标签页头+内容列表） |
| dashboard.notification-item | q6BmF | 通知列表项（标题+红点+时间） |

## Tier颜色映射

| Tier | 背景色 | 文字色 |
|------|--------|--------|
| P0 | #FEE2E2 | #DC2626 |
| P1 | #FEF3C7 | #D97706 |
| P2 | #FEF9C3 | #CA8A04 |
| P3 | #DBEAFE | #2563EB |
