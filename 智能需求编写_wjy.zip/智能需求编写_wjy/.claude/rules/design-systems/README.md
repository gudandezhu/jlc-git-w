# 设计系统配置说明

## 概述

本目录包含PRD工作流所使用的设计系统配置。通过将组件ID、设计Token和页面规范从工作流中解耦，支持切换不同的组件库。

## 目录结构

```
design-systems/
├── README.md              ← 本文件
├── dayu/                  ← 大禹平台设计系统（当前激活）
│   ├── component-map.md   ← 组件ID映射
│   ├── design-tokens.md   ← 设计Token（颜色/字体/间距）
│   └── design-rules.md    ← 页面样式强制规范
└── antd/                  ← Ant Design（模板，待填充）
    ├── component-map.md
    ├── design-tokens.md
    └── design-rules.md
```

## 切换设计系统

1. 准备对应设计系统的 `.pen` 组件库文件
2. 填充 `component-map.md`（组件ID映射）
3. 填充 `design-tokens.md`（设计Token）
4. 填充 `design-rules.md`（页面样式规范）
5. 在 `rules/product-specs-workflow.md` 顶部修改 `当前激活的设计系统` 为新系统名称

## 新增设计系统

1. 在 `design-systems/` 下创建新目录（如 `material/`）
2. 复制 `antd/` 模板文件
3. 按照模板格式填充配置
4. 制作对应的 `.pen` 组件库文件（包含 reusable 组件）
