# 项目目录结构说明

## 概述

本项目是**AI产品需求文档编写助手**，专门用于辅助产品经理编写IT产品需求文档。采用模块化的文档组织结构，确保规范清晰、易于维护和扩展。

## 根目录结构

```
Claude产品需求/
├── .claude/              # Claude AI配置目录
│   ├── agents/           # Agent提示词定义
│   ├── commands/         # 快捷命令入口
│   ├── skills/           # AI技能定义（UI/UX Pro Max）
│   └── settings.json     # 配置文件
│
├── rules/                # 核心规范文档（独立在根目录）
├── prd/                  # PRD文档输出目录
├── wiki/                 # Wiki文档输出目录
└── README.md             # 项目说明
```

## 详细目录结构

### 1. `.claude/agents/` - Agent提示词定义

存放各专业Agent的完整提示词，每个Agent负责特定的任务类型。

```
.claude/agents/
├── README.md                           # Agent索引和说明
├── requirement-analysis-agent.md        # 需求分析Agent
├── prd-writing-agent.md                # PRD编写Agent
├── requirement-review-agent.md         # 需求自审Agent
├── ui-ux-design-agent.md               # UI/UX设计Agent
└── wiki-writing-agent.md               # Wiki编写Agent
```

**Agent职责**：

| Agent | 角色 | 主要职责 | 输出文档 |
|-------|------|----------|----------|
| 需求分析Agent | 资深产品设计顾问 | 需求背景分析、用户角色分析、策略分析 | 01-requirements-analysis.md |
| PRD编写Agent | 资深IT产品经理 | 按规范编写完整PRD文档 | 05-prd.md |
| 需求自审Agent | 产品质量审核专家 | 分级自审、问题识别、改进建议 | 07-self-review.md |
| UI/UX设计Agent | 资深UI/UX设计师 | Pencil原型设计、交互设计 | 06-prototype.pen |
| Wiki编写Agent | 技术文档编写专家 | 快速创建轻量级Wiki文档 | Wiki文档 |

---

### 2. `.claude/commands/` - 快捷命令入口

存放用户可调用的快捷命令定义，每个命令激活对应的Agent。

```
.claude/commands/
├── README.md              # 命令索引和使用说明
├── prd.md                 # PRD编写命令
├── check.md               # PRD质量检查命令
└── wiki.md                # Wiki编写命令
```

**命令使用**：

- `/prd` - 按照完整工作流程创建PRD文档
- `/check` - PRD文档质量检查和自审
- `/wiki` - 快速创建轻量级Wiki文档

---

### 3. `.claude/skills/` - AI技能定义

存放可复用的AI技能，供Agent调用。

```
.claude/skills/
└── ui-ux-pro-max/         # UI/UX Pro Max技能
    ├── skill.md           # 技能定义
    └── reference/         # 参考数据和脚本
        ├── data/          # 设计数据（色彩、字体、风格等）
        └── scripts/       # Python脚本（设计调研）
```

**使用场景**：在原型设计阶段自动激活UI/UX设计师角色时调用。

---

### 4. `rules/` - 核心规范文档

存放产品需求编写的所有规范、指南和工作流程文档。

```
rules/
├── README.md                           # 规范文档导航索引
├── product-specs-workflow.md           # 【核心】产品需求Specs完整工作流程
├── prd-writing-guide.md                # 【核心】PRD文档编写详细规范
├── review-workflow.md                  # 【核心】需求文档自审工作流程
├── wiki-writing-guide.md               # Wiki文档编写规范
├── specialized-roles.md                # 专业角色切换指南
└── user-manual.md                      # 用户操作手册编写规范
```

**规范分类**：

| 分类 | 文档 | 用途 |
|------|------|------|
| **工作流程** | product-specs-workflow.md | 定义8个阶段的完整需求开发流程 |
| **编写规范** | prd-writing-guide.md | 规范PRD文档的7个核心章节 |
| **审核规范** | review-workflow.md | 定义分级自审机制和流程 |
| **Wiki规范** | wiki-writing-guide.md | 规范轻量级Wiki文档编写 |
| **角色定义** | specialized-roles.md | 定义UI/UX设计师等专业角色 |
| **用户手册** | user-manual.md | 规范用户操作手册编写 |

---

### 5. `prd/` - PRD文档输出目录

存放正式的产品需求规格文档，每个功能特性一个独立目录。

```
prd/
├── {feature-name}/                     # 功能特性目录（kebab-case命名）
│   ├── 01-requirements-analysis.md    # 阶段1：需求分析
│   ├── 02-feature-scope.mm             # 阶段2：功能范围脑图（FreeMind格式，XMind可打开）
│   ├── 03-er-diagram.drawio               # 阶段3：数据模型和实体关系
│   ├── 04-user-use-cases.drawio           # 阶段4：用户角色和用例
│   ├── 05-prd.md                      # 阶段5：产品需求文档（PRD）
│   ├── 06-prototype.pen               # 阶段6：原型设计（Pencil原型）
│   ├── 06-prototype-test-report.md    # 阶段6：原型自测报告
│   ├── 07-self-review.md              # 阶段7：自审记录
│   └── assets/                         # 资源文件夹
│       ├── 03-workflow.drawio          # 业务流程图
│       └── 03-dataflow.drawio         # 数据流图（多系统时必须）
│
└── README.md                           # PRD目录索引（可选）
```

**文件命名规范**：
- **目录名**：kebab-case格式（如：`user-data-export`、`permission-management`）
- **文档名**：英文命名（kebab-case，如：`01-requirements-analysis.md`）

**8个核心阶段**：
1. 需求分析（01-requirements-analysis.md）
2. 功能范围脑图（02-feature-scope.mm）
3. 产品模块ER关系图（03-er-diagram.drawio）
4. 用户用例全景图（04-user-use-cases.drawio）
5. 产品需求文档（05-prd.md）
6. 原型设计（06-prototype.pen + 06-prototype-test-report.md）
7. 需求文档自审（07-self-review.md，必须）
8. 需求变更管理（08-changelog.md，按需）

---

### 6. `wiki/` - Wiki文档输出目录

存放轻量级的需求收集、技术说明、知识分享等文档。

```
wiki/
└── modules/                            # 按模块组织文档
    ├── dayu-platform/                  # 大禹平台相关
    │   ├── README.md                   # 模块索引
    │   ├── {功能名称}-需求.md
    │   └── {功能名称}-用户操作手册.md
    │
    ├── apim/                           # API管理平台
    ├── security/                       # 安全相关（凭据管理等）
    ├── monitoring/                     # 监控系统
    ├── approval-workflow/              # 审批流程
    ├── infrastructure/                 # 基础架构
    ├── gateway/                        # 网关相关
    ├── frontend-monitoring/            # 前端监控
    ├── code-repository/                # 代码仓库管理
    └── general/                        # 通用规范、设计系统
```

**模块选择指南**：

| 文档类型 | 目标模块 |
|---------|---------|
| 大禹平台功能 | `modules/dayu-platform/` |
| API管理相关 | `modules/apim/` |
| 凭据管理、安全功能 | `modules/security/` |
| 监控、告警功能 | `modules/monitoring/` |
| 审批流程相关 | `modules/approval-workflow/` |
| 基础架构规划 | `modules/infrastructure/` |
| 网关配置管理 | `modules/gateway/` |
| 前端监控分析 | `modules/frontend-monitoring/` |
| 代码仓库管理 | `modules/code-repository/` |
| 通用规范、设计系统 | `modules/general/` |

**文件命名规范**：
- 需求文档：`{功能名称}-需求.md`
- 用户手册：`{功能名称}-用户操作手册.md`
- 设计文档：`{功能名称}-设计文档.md`
- 会议纪要：`{日期}-{会议主题}.md`

---

## 文档关系图

```
rules/product-specs-workflow.md (主流程)
├── rules/prd-writing-guide.md (PRD编写规范)
├── rules/review-workflow.md (自审流程)
├── rules/specialized-roles.md (角色切换)
│   └── .claude/skills/ui-ux-pro-max/ (UI/UX技能)
└── rules/wiki-writing-guide.md (Wiki规范)

.claude/agents/ (Agent实现)
├── 引用 rules/product-specs-workflow.md
├── 引用 rules/prd-writing-guide.md
└── 引用 rules/review-workflow.md

.claude/commands/ (快捷入口)
└── 激活 .claude/agents/ 中的对应Agent

prd/ (输出目录)
└── 按照 rules/product-specs-workflow.md 生成文档

wiki/ (输出目录)
└── 按照 rules/wiki-writing-guide.md 生成文档
```

---

## 目录维护原则

### 1. 职责分离

| 目录类型 | 职责 | 示例 |
|---------|------|------|
| **rules/** | 定义规范（做什么） | 工作流程、编写指南 |
| **agents/** | 定义实现（怎么做） | Agent提示词、执行逻辑 |
| **commands/** | 提供入口（快速调用） | 快捷命令 |

### 2. 命名规范

- **PRD目录名**：kebab-case（如 `user-data-export`）
- **文档名称**：英文命名（kebab-case，如 `01-requirements-analysis.md`）
- **Wiki文档**：描述性命名（如 `用户权限-需求.md`）

### 3. 模块化管理

- 每个功能特性独立目录
- 按业务模块分类Wiki文档
- 清晰的目录边界

---

## 使用建议

### 新建PRD文档时

1. 使用 `/prd` 命令启动工作流程
2. 选择完整流程或快速模式
3. 按照8个阶段依次创建文档
4. 在 `prd/{feature-name}/` 目录下保存文档

### 新建Wiki文档时

1. 使用 `/wiki` 命令
2. 选择文档类型和所属模块
3. 在 `wiki/modules/{模块名}/` 目录下创建文档
4. 更新模块的README.md索引

### 质量检查时

1. 使用 `/check` 命令
2. 选择自审级别（轻量/标准/完整）
3. 逐项检查并改进
4. 保存自审记录

---

## 总结

本项目的目录结构设计遵循以下原则：

1. **规范独立**：rules独立在根目录，便于团队成员查看和维护
2. **职责清晰**：agents、commands、rules各司其职
3. **输出分离**：prd和wiki作为输出目录，与配置分离
4. **命名统一**：使用一致的命名规范，便于理解和维护
5. **可扩展性**：预留扩展空间，便于未来添加新功能

通过这种结构化的组织，确保产品需求文档编写的专业性、规范性和高效性。
