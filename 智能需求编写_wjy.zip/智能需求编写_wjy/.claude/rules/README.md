# 规范文档导航

本目录包含产品需求文档编写的所有核心规范和工作流程。

## 📋 文档分类

### 🎯 核心工作流程
- **[product-specs-workflow.md](./product-specs-workflow.md)** - 产品需求Specs完整工作流程（8个阶段+5个质量关卡）
- **[review-workflow.md](./review-workflow.md)** - 需求文档自审工作流程（分级自审）

### 📝 文档编写规范
- **[prd-writing-guide.md](./prd-writing-guide.md)** - PRD文档编写详细规范
- **[wiki-writing-guide.md](./wiki-writing-guide.md)** - Wiki文档编写规范
- **[user-manual.md](./user-manual.md)** - 用户操作手册编写规范

### 🎭 质量检查指南
- **[prototype-self-test-guide.md](./prototype-self-test-guide.md)** - 原型自测指南（类比代码自测）

### 🎨 角色定义
- **[specialized-roles.md](./specialized-roles.md)** - 专业角色切换指南（UI/UX设计师等）

### 📚 项目信息
- **[structure.md](./structure.md)** - 项目目录结构说明

---

## 🚀 快速开始

### 使用快捷命令

```bash
/prd    # 创建PRD文档
/check  # PRD质量检查
/wiki   # 创建Wiki文档
```

### 创建PRD文档时

1. 使用 `/prd` 命令启动工作流程
2. 选择完整流程或快速模式
3. 在 `prd/{feature-name}/` 目录下生成文档

**输出目录结构**：
```
prd/{feature-name}/
├── 01-requirements-analysis.md
├── 02-feature-scope.mm
├── 02-feature-scope-checklist.md       # 质量关卡1输出
├── 03-er-diagram.md
├── 03-er-checklist.md                  # 质量关卡2输出
├── 04-user-use-cases.md
├── 04-use-cases-checklist.md           # 质量关卡3输出
├── 05-prd.md
├── 05-prd-checklist.md                 # 质量关卡4输出
├── 06-prototype.pen（可选）
├── 06-prototype-test-report.md         # 质量关卡5输出（必须）
├── 07-self-review.md
└── 08-changelog.md（按需）
```

### 创建Wiki文档时

1. 使用 `/wiki` 命令
2. 选择文档类型和所属模块
3. 在 `wiki/modules/{模块名}/` 目录下创建文档

---

## 📖 文档关系图

```
product-specs-workflow.md (主流程)
├── prd-writing-guide.md (PRD编写规范)
├── review-workflow.md (自审流程)
├── prototype-self-test-guide.md (原型自审指南) ⭐新增
├── specialized-roles.md (角色切换)
│   └── .claude/skills/ui-ux-pro-max/ (UI/UX技能)
└── wiki-writing-guide.md (Wiki规范)

.claude/agents/ (Agent实现)
└── 引用上述规范文档

.claude/commands/ (快捷入口)
└── 激活对应的Agent

.claude/templates/ (检查清单模板)
├── feature-scope-checklist.md       # 功能范围自审清单
├── prd-consistency-checklist.md     # PRD一致性检查清单
└── prototype-self-test-report.md    # 原型自测报告
```

---

## 🎯 核心工作流程说明

### 产品需求Specs工作流程（8个阶段+5个质量关卡）

**8个核心阶段**：

1. **需求分析** - 深入理解需求本质和价值
2. **功能范围脑图** - 明确功能边界，梳理功能结构
3. **产品模块ER关系图** - 数据模型梳理，实体关系定义
4. **用户用例全景图** - 用户角色定义，用例场景梳理
5. **产品需求文档** - 详细的功能需求和实现规范
6. **原型设计**（可选）- 可交互的原型设计
7. **需求文档自审**（必须）- 分级自审，确保质量
8. **需求变更管理**（按需）- 规范需求变更流程

**5个质量关卡** ⭐新增：

1. **质量关卡1**（阶段2后）：功能范围自审
2. **质量关卡2**（阶段3后）：ER关系图自审
3. **质量关卡3**（阶段4后）：用例全景图自审
4. **质量关卡4**（阶段5后）：PRD一致性检查
5. **质量关卡5**（阶段6后）：原型自测（必须）

**两种工作模式**：
- **完整流程**：适用于中大型需求或需求不明确的场景
- **快速模式**：适用于需求明确的小型需求

### 需求文档自审工作流程

**分级自审机制**：
- **轻量级**（5项检查）：小型需求（1-3人天）
- **标准级**（10项检查）：中型需求（4-10人天）
- **完整级**（15项检查）：大型需求（10+人天）

### 原型自审工作流程 ⭐新增

**类比代码自测**：
- **覆盖度检查**：原型是否覆盖所有功能
- **操作闭环测试**：模拟真实用户操作流程
- **界面元素检查**：所有元素可交互、有反馈
- **用户体验检查**：可用性、一致性、视觉设计

**通过标准**：
- 功能覆盖率 ≥ 90%
- 操作闭环测试通过率 ≥ 85%
- 界面元素可交互率 ≥ 95%
- 用户体验评分 ≥ 3星

---

## 📂 目录结构说明

### 规范文档（rules/）

存放核心规范和工作流程，独立于配置目录，便于团队查看和维护。

### Agent定义（.claude/agents/）

存放各专业Agent的提示词，每个Agent负责特定任务类型。

### 快捷命令（.claude/commands/）

存放用户可调用的快捷命令，每个命令激活对应的Agent。

### 检查清单模板（.claude/templates/）⭐新增

存放各质量关卡的检查清单模板：
- 功能范围自审清单
- PRD一致性检查清单
- 原型自测报告

### 输出目录

- **prd/** - PRD文档输出目录
- **wiki/** - Wiki文档输出目录

---

## 🔄 文档更新原则

- **单一职责**：每个文档只负责一个明确的领域
- **避免重复**：相同内容只在一个文档中维护
- **持续优化**：根据使用反馈持续改进文档结构
- **实际优先**：文档结构与实际使用保持一致
- **质量优先**：每个关键阶段都有质量关卡

---

*最后更新：2025-01-23*
*版本：v2.0（新增质量关卡体系）*
