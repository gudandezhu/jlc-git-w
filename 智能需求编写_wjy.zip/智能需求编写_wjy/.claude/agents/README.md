# Agent 索引

本目录包含 9 个 Agent 的提示词定义 + 5 个 Phase 文件，覆盖产品需求 Specs 工作流的完整 8 个阶段。

---

## Agent 总览

### 编排 Agent（1 个）

| # | Agent名称 | 文件 | 主要职责 |
|---|-----------|------|----------|
| 0 | **Lead PRD Agent** | lead-prd-agent.md | 工作流自动编排：阶段检测、sub-agent调度、并行执行、上下文管理、经验库注入 |

### 核心流程 Agent（7 个）

| # | Agent名称 | 文件 | 覆盖阶段 | 主要职责 |
|---|-----------|------|----------|----------|
| 1 | **需求分析Agent** | requirement-analysis-agent.md | 阶段1 | 需求元数据、背景目标、需求挑战、用户角色、策略分析 |
| 2 | **功能架构Agent** | feature-architect-agent.md | 阶段2+3+4 | 范围决策、功能范围脑图、ER关系图、用户用例全景图 |
| 3 | **PRD编写Agent** | prd-writing-agent.md | 阶段6 | 按规范编写完整PRD文档（列表/按钮/表单） |
| 4 | **UI/UX设计Agent** | ui-ux-design-agent.md | 阶段7 | Pencil原型设计、大禹组件库、设计调研 |
| 5 | **原型质量验证Agent** | prototype-qa-agent.md | 阶段7（验证） | 原型自测（6维度打分）、产品设计审查、设计规范合规检查 |
| 6 | **需求自审Agent** | requirement-review-agent.md | 阶段8 | 分级自审（5/10/15项）、问题识别、改进建议 |
| 7 | **需求变更管理Agent** | change-management-agent.md | 阶段9 | 变更影响评估、多文档联动更新、变更日志 |

### 辅助 Agent（1 个）

| # | Agent名称 | 文件 | 主要职责 |
|---|-----------|------|----------|
| 8 | **Wiki编写Agent** | wiki-writing-agent.md | 快速创建轻量级Wiki文档、需求收集 |

### Phase 文件（渐进式加载）

大型 Agent 拆分为阶段性 Phase 文件，由 Lead Agent 按需加载，减少 context 占用：

| 原 Agent | Phase 文件 | 职责 |
|----------|-----------|------|
| PRD编写Agent | prd-phases/prd-phase-prepare.md | 准备阶段：前置条件、知识库核对、编写策略 |
| PRD编写Agent | prd-phases/prd-phase-modeling.md | 建模阶段：ER图、用例图、上下文快照（支持并行） |
| PRD编写Agent | prd-phases/prd-phase-writing.md | 编写阶段：模块化PRD编写 |
| UI/UX设计Agent | ui-ux-phases/design-research.md | 设计调研：需求确认、风格调研、策略制定 |
| UI/UX设计Agent | ui-ux-phases/prototype-creation.md | 原型创建：Pencil/HTML原型生成、验证 |

---

## 执行模式

### 自动编排模式（`/prd-auto`，推荐）

Lead PRD Agent 作为统一入口，自动检测阶段并调度 sub-agent：

```
用户输入需求 → Lead PRD Agent
  ├─ 检测 prd/{module}/{slug}/ 目录文件 → 判断当前阶段
  ├─ 调度对应 sub-agent（按需加载 phase 文件）
  ├─ 注入经验记忆库提醒
  ├─ 接收结果 → 更新 context-snapshot
  ├─ 向用户汇报 → 确认后进入下一阶段
  └─ 支持并行：ER图+用例图并行、验证+自审并行
```

### 手动模式（`/prd`、`#agent-name`）

直接激活特定 Agent，适合单阶段修改或调试。两种模式产出文件格式一致，可随时互切。

---

## 完整协作流程

```
用户提出需求
    ↓
[0] lead-prd-agent（自动编排，可选）
    ↓ 自动检测阶段并调度 ↓
[1] requirement-analysis-agent（阶段1：需求分析）
    ↓ 输出 01-requirements-analysis.md → 更新 context-snapshot
[2] feature-architect-agent（阶段2+3+4：功能建模）
    ↓ 输出 02-feature-scope.mm
    ↓ 并行组A：ER图 + 用例图同时生成
    ↓ 输出 03-er-diagram.drawio + 04-user-use-cases.drawio → 更新 context-snapshot
[3] prd-writing-agent（阶段6：PRD 编写）
    ↓ 输出 06-prd.md → 更新 context-snapshot
[4] ui-ux-design-agent（阶段7：原型设计）
    ↓ 输出 07-prototype.pen → 更新 context-snapshot
    ↓ 并行组B：原型验证 + 需求自审同时执行
[5] prototype-qa-agent（阶段7验证：原型自测+设计审查）
    ↓ 输出 07-prototype-test-report.md
    ↓ 不通过 → 返回 [4] 修改
[6] requirement-review-agent（阶段8：需求自审）
    ↓ 输出 08-self-review.md → 更新 context-snapshot
    ↓ 不通过 → 返回对应 agent 修改
[7] change-management-agent（阶段9：变更管理，按需）
    ↓ 输出 09-changelog.md
```

---

## Context Snapshot 机制

每个阶段完成后自动更新 `prd/{module}/{slug}/05-context-snapshot.md`，下一阶段只读摘要而非全部历史：

- 模板：`.claude/templates/context-snapshot.md`
- 每个 Agent/Phase 文件都有「Context Snapshot 协作」区块，明确读取和更新规则
- Lead Agent 在阶段切换时负责汇总和更新

## 经验记忆库

Lead Agent 在调度 sub-agent 时自动注入相关经验：

| Memory 文件 | 注入时机 |
|------------|---------|
| feedback_prd_top10_issues.md | PRD编写阶段 — 高频问题提醒 |
| feedback_prd_domain_patterns.md | PRD编写阶段 — 按需求类型注入坑点 |
| feedback_prd_predev_checklist.md | 验证自审阶段 — 开发前必检清单 |
| project_prd_quality_baseline.md | 验证自审阶段 — 评分基准对标 |

---

## Agent 激活方式

在对话中使用以下关键词激活对应Agent：

| Agent | 激活关键词 |
|-------|----------|
| Lead PRD Agent | `#lead-prd` 或 `#PRD编排` |
| 需求分析Agent | `#requirement-analysis` 或 `#需求分析` |
| 功能架构Agent | `#feature-architect` 或 `#功能建模` |
| PRD编写Agent | `#prd-writing` 或 `#PRD编写` |
| UI/UX设计Agent | `#ui-designer` 或 `#原型设计` |
| 原型质量验证Agent | `#prototype-qa` 或 `#原型验证` |
| 需求自审Agent | `#requirement-review` 或 `#需求自审` |
| 需求变更管理Agent | `#change-management` 或 `#需求变更` |
| Wiki编写Agent | `#wiki-writing` 或 `#Wiki编写` |

---

## 文档结构

```
.claude/agents/
├── README.md                          # 本文档
├── lead-prd-agent.md                  # 编排器：自动检测+调度+并行+经验库
├── requirement-analysis-agent.md       # 阶段1：需求分析
├── feature-architect-agent.md          # 阶段2+3+4：功能建模
├── prd-writing-agent.md               # 阶段6：PRD编写（入口）
├── prd-phases/                        # PRD编写渐进加载
│   ├── prd-phase-prepare.md           #   准备阶段
│   ├── prd-phase-modeling.md          #   建模阶段（支持并行）
│   └── prd-phase-writing.md           #   编写阶段
├── ui-ux-design-agent.md              # 阶段7：原型设计（入口）
├── ui-ux-phases/                      # UI/UX渐进加载
│   ├── design-research.md             #   设计调研
│   └── prototype-creation.md          #   原型创建
├── prototype-qa-agent.md              # 阶段7验证：原型自测+设计审查
├── requirement-review-agent.md        # 阶段8：需求自审
├── change-management-agent.md         # 阶段9：变更管理
├── user-manual-writing-agent.md       # 辅助：用户手册编写
└── wiki-writing-agent.md              # 辅助：Wiki编写
```

---

## 版本记录

- v3.0（2026-04-13）：借鉴DeerFlow，新增Lead Agent自动编排、渐进加载、Context Snapshot、并行调度、经验记忆库
- v2.0（2026-03-27）：新增功能架构Agent、原型质量验证Agent、需求变更管理Agent，覆盖完整8阶段
- v1.1（2025-01-23）：添加Wiki编写Agent
- v1.0（2025-01-23）：初始版本，创建4个核心Agent

---

*最后更新：2026-04-16*
*版本：v3.1*
