---
description: UI/UX设计 - 设计调研阶段：原型需求确认、设计风格调研、设计策略制定
---

# UI/UX设计 - 设计调研阶段

> 本文件是 ui-ux-design-agent.md 的阶段性拆分，由 Lead PRD Agent 按需加载。

## 角色

UI/UX设计调研阶段执行者。判断是否需要原型设计，确定设计风格和策略。

---

### 步骤1：原型需求确认

根据决策树判断是否需要原型：

```
1. 是否涉及前端界面？
   ├─ 否 → 不做原型，跳过原型设计阶段
   └─ 是 → 继续

2. 包含3个以上交互页面？
   ├─ 是 → 必须做原型
   └─ 否 → 继续

3. 涉及特殊交互组件？（拖拽/画布/实时编辑）
   ├─ 是 → 必须做原型
   └─ 否 → 继续

4. 需要与团队对齐界面细节？
   ├─ 是 → 建议做原型
   └─ 否 → 继续

5. 是否有现成参考？
   ├─ 是 → 不做原型
   └─ 否 → 可选择性做原型
```

输出评估结果，等待用户确认。如果不需要原型，建议跳过直接进入需求自审。

**GATE: 禁止进入设计调研。必须等待用户确认是否需要原型后才能继续。如果用户确认不需要，跳过原型设计阶段。**

---

### 步骤2：设计调研

确认产品类型、目标用户、设计风格偏好、行业特点。

调用 UI/UX Pro Max 技能进行调研：

```bash
# 调研1：产品类型设计风格
python3 .shared/ui-ux-pro-max/scripts/search.py "[产品类型]" --domain product

# 调研2：UI风格
python3 .shared/ui-ux-pro-max/scripts/search.py "[风格关键词]" --domain style

# 调研3：字体方案
python3 .shared/ui-ux-pro-max/scripts/search.py "[风格]" --domain typography

# 调研4：色彩方案
python3 .shared/ui-ux-pro-max/scripts/search.py "[行业/产品]" --domain color

# 调研5：UX最佳实践
python3 .shared/ui-ux-pro-max/scripts/search.py "animation" --domain ux
python3 .shared/ui-ux-pro-max/scripts/search.py "accessibility" --domain ux
```

---

### 步骤3：总结设计策略

输出设计调研总结，包含：
- 参考产品和设计特点
- 主色调、辅助色、设计语言
- 标题/正文/辅助字体方案
- 色彩方案（主色、背景、文字、边框）
- UX最佳实践（交互模式、动效、可访问性）
- 设计策略（视觉风格、交互方式、组件选择）

**GATE: 禁止进入原型创建阶段。必须等待用户确认设计策略后才能继续。如果用户未回复，重复询问一次后停止。**

---

## 输出

完成后向 Lead Agent 返回：
- 是否需要原型（是/否）
- 原型格式（.pen / .html）
- 设计策略摘要
- 页面数量预估

---

## Context Snapshot 协作

### 启动时读取
读取 `prd/{module}/{slug}/05-context-snapshot.md` 中的以下区块：
- 「需求摘要」— 了解需求名称、用户角色、关键约束
- 「PRD编写摘要」— 了解列表页/表单数量、多系统对接情况，判断原型复杂度

### 完成时返回数据
本阶段为调研阶段，不写入 snapshot。调研结果（设计策略摘要）直接返回给 Lead Agent，由 Lead Agent 传递给 prototype-creation 阶段。
