---
description: PRD自动编排 - 统一入口，自动检测阶段并调度sub-agent完成完整PRD流程
inclusion: manual
---

# prd-auto 命令

## 命令说明

使用 Lead PRD Agent 自动编排完整的 PRD 工作流。Agent 会自动检测当前项目进度，调度对应阶段的 sub-agent，并在阶段间维护上下文摘要。

## 快速开始

激活 `.claude/agents/lead-prd-agent.md`，按照该 Agent 定义的编排逻辑自动执行。

## 使用方式

### 新建项目
```
/prd-auto 我需要做一个XXX功能
```

### 继续已有项目
```
/prd-auto 继续 {slug} 项目
```

### 从指定阶段开始
```
/prd-auto {slug} 从阶段3开始
```

## 与手动模式的区别

| 特性 | /prd-auto（自动编排） | /prd（手动模式） |
|------|---------------------|-----------------|
| 阶段切换 | 自动检测并调度 | 手动用 # 关键词切换 |
| 上下文管理 | 自动维护 context-snapshot | 依赖同一会话上下文 |
| Sub-Agent 加载 | 按阶段加载 phase 文件 | 加载完整 agent 定义 |
| 适用场景 | 完整走流程 | 单阶段修改或调试 |

## 相关规范

- **编排逻辑**：`.claude/agents/lead-prd-agent.md`
- **上下文模板**：`.claude/templates/context-snapshot.md`
- **工作流程**：`.claude/rules/product-specs-workflow.md`
- **编写规范**：`.claude/rules/prd-writing-guide.md`

---
