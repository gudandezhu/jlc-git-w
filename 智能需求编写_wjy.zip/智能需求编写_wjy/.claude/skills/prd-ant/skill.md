---
description: PRD编写（Ant Design） - 使用Ant Design组件库创建PRD和原型
inclusion: manual
---

# prd-ant 命令

## 命令说明

使用**Ant Design设计系统**，按照 `.claude/rules/product-specs-workflow.md` 定义的产品需求Specs工作流程，创建完整的产品需求文档和原型。

## 设计系统

- **设计系统**：Ant Design 5.x（antd）
- **组件库文件**：`/Users/wangjunyi/Desktop/工作/设计/ant.pen`
- **组件映射**：`.claude/rules/design-systems/antd/component-map.md`
- **设计Token**：`.claude/rules/design-systems/antd/design-tokens.md`
- **页面规范**：`.claude/rules/design-systems/antd/design-rules.md`

## 快速开始

1. 激活 `.claude/agents/prd-writing-agent.md`
2. 原型设计阶段，使用 Ant Design 组件库（`ant.pen`）
3. 组件ID查找：参考 `.claude/rules/design-systems/antd/component-map.md`

## 设计系统特点

- 暗色侧边栏布局（layout.list-page = aSSt8）
- 主色 #1677FF
- 字体：Inter（统一）
- 30个可复用组件
- 按钮高度 32px，圆角 6px
- 表格行高 54px

## 相关规范

- **工作流程**：`.claude/rules/product-specs-workflow.md`
- **编写规范**：`.claude/rules/prd-writing-guide.md`
- **原型自测**：`.claude/rules/prototype-self-test-guide.md`
- **自审流程**：`.claude/rules/review-workflow.md`

---
