---
description: 产品需求文档编写 - 按照完整工作流程创建PRD
inclusion: manual
---

# prd 命令

## 命令说明

按照 `.claude/rules/product-specs-workflow.md` 定义的产品需求Specs工作流程，创建完整的产品需求文档。

> **推荐使用 `/prd-auto`**：自动编排模式，Lead Agent 自动检测阶段、调度 sub-agent、管理上下文、注入经验库。
> `/prd` 为手动模式，适合单阶段修改或调试。

## 快速开始

激活 `.claude/agents/prd-writing-agent.md`，按照该Agent定义的工作流程执行任务。

## 相关规范

- **工作流程**：`.claude/rules/product-specs-workflow.md`
- **编写规范**：`.claude/rules/prd-writing-guide.md`
- **设计规范**：`.claude/rules/dayu-design-system.md`（含第15章页面样式强制规范）
- **原型自测**：`.claude/rules/prototype-self-test-guide.md`
- **自审流程**：`.claude/rules/review-workflow.md`

## 相关命令

- `/prd-auto` — 自动编排模式（推荐，Lead Agent 统一调度）
- `/prd-dayu` — 手动模式 + 大禹设计系统
- `/prd-ant` — 手动模式 + Ant Design
- `/check` — PRD 质量快速检查
- `/prototype-iterate` — 原型多轮迭代优化（独立使用，无需跑完整 PRD 流程）

---
