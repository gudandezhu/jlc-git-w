---
description: PRD编写（大禹设计系统） - 使用大禹平台组件库创建PRD和原型
inclusion: manual
---

# prd-dayu 命令

## 命令说明

使用**大禹平台设计系统**，按照 `.claude/rules/product-specs-workflow.md` 定义的产品需求Specs工作流程，创建完整的产品需求文档和原型。

## 设计系统

- **设计系统**：大禹平台（dayu）
- **组件库文件**：`/Users/wangjunyi/Desktop/工作/设计/dayu_platform.lib.pen`
- **组件映射**：`.claude/rules/design-systems/dayu/component-map.md`
- **设计Token**：`.claude/rules/design-systems/dayu/design-tokens.md`
- **页面规范**：`.claude/rules/design-systems/dayu/design-rules.md`
- **完整参考**：`.claude/rules/dayu-design-system.md`

## 快速开始

1. 激活 `.claude/agents/prd-writing-agent.md`
2. 原型设计阶段，复制大禹组件库到项目目录并在 VS Code 中打开以激活 Pencil MCP 连接。文件导出使用 Pencil CLI：`pencil --export`
3. 组件ID查找：参考 `.claude/rules/design-systems/dayu/component-map.md`

## 设计系统特点

- 暗色侧边栏布局（layout.list-page = MtsyV）
- 主色 #1890FF
- 字体：Space Grotesk（标题）+ Inter（正文）
- 172个可复用组件
- 表格可用宽度 1112px

## 平台知识库

当编写大禹平台相关需求时，Agent 必须参考平台产品知识库了解现有功能：

- **知识库索引**：`大禹平台产品知识库.md`（平台总览、完整导航结构、通用交互模式）
- **知识库目录**：`大禹平台产品知识库/`（13个模块，80+个子页面文档）
- **模块概述文件**：每个模块目录下的 `{模块名}-概述.md`（模块定位、核心业务流程、子页面索引）
- **变更日志**：`大禹平台产品知识库/CHANGELOG.md`（知识库变更历史）

### 使用规则

1. **阶段1（需求分析）启动时**：必须先读取 `大禹平台产品知识库.md` 了解平台全貌和导航结构
2. **识别关联模块**：根据需求描述，定位涉及的模块目录，读取对应的 `概述.md`
3. **深入子页面**（⚠️ 强制）：当需求涉及具体页面的改造或关联时，必须读取对应的子页面文档，逐字段记录现有筛选条件、列表字段、操作按钮、统计卡片、数据规模
4. **阶段6（PRD编写）时**（⚠️ 强制）：
   - 必须重新读取知识库中每个涉及页面的子页面文档
   - 增强型页面的字段表格必须先完整列出现有字段（标注"现有"），再列出新增字段（标注"新增"）
   - 禁止凭记忆描述现有页面结构，必须以知识库文档为准
5. **阶段7（原型设计）时**（⚠️ 强制）：
   - 增强型页面的原型必须先还原现有页面结构，再叠加新增功能
   - 必须核对知识库中的现有字段数量、表格结构、数据规模，确保原型与现有页面一致
   - 必须用 Playwright 访问现有页面截图，以实际页面布局为基准（知识库可能遗漏图表、多区域表格等）
6. **PRD/Wiki通过后**：同步更新知识库中受影响的模块文档，并在 CHANGELOG.md 中记录变更

## 相关规范

- **工作流程**：`.claude/rules/product-specs-workflow.md`
- **编写规范**：`.claude/rules/prd-writing-guide.md`
- **设计规范**：`.claude/rules/dayu-design-system.md`（含第15章页面样式强制规范）
- **原型自测**：`.claude/rules/prototype-self-test-guide.md`
- **自审流程**：`.claude/rules/review-workflow.md`
- **平台知识库**：`大禹平台产品知识库.md`（现有功能参考）

---
