---
name: codebeat-cli
description: |
  Manage AI-generated documentation and files using CodeBeat CLI tool.

  Use this skill whenever the user mentions:
  - 文件管理, 管理文件, 整理文档, 组织文档 (file management, organize docs)
  - AI编程Wiki文档, AI生成文档, ChatGPT文档, Claude对话记录 (AI-generated docs)
  - 文件上传, 批量上传, 上传文档, 上传目录 (file upload, batch upload, upload directory)
  - 文件下载, 下载文档, 批量下载, 递归下载 (file download, batch download, recursive download)
  - CodeBeat, codebeat, or codebeat-cli
  - Document management for AI-generated content
  - Uploading/downloading markdown files
  - Managing technical documentation, organizing knowledge base
  - 批量操作, 递归上传, 递归下载, 文档同步 (batch operations, recursive upload/download, doc sync)

  ESPECIALLY USE THIS SKILL when users want to:
  - Upload multiple files or entire directories (recursive upload with -R)
  - Download entire directories recursively (recursive download with -R)
  - Organize AI conversations by topic/project
  - Batch upload/download markdown documentation
  - Manage ChatGPT/Claude conversation outputs
  - Create organized workspaces for AI-generated content

  This skill helps users configure CodeBeat CLI and perform file operations including upload, download, query, and search of AI-generated documents with powerful batch and organization capabilities.

  Even if the user doesn't explicitly mention CodeBeat, use this skill when they want to manage AI-generated files, upload/download documentation, or organize technical knowledge.
---

# CodeBeat CLI Assistant

Expert assistant for CodeBeat CLI - managing AI-generated documentation with cloud storage and configuration management.

## Overview

CodeBeat CLI helps developers manage AI-generated documents (from Claude, ChatGPT, Cursor, etc.) with:
- Cloud storage and organization
- Git-style three-level configuration (global/project/directory)
- Batch upload/download with directory structure preservation
- Workspace organization for AI-generated content

## Core Capabilities

1. **Configuration** - Interactive setup for token, space, and parentKey
2. **Workspace Organization** - Use `codebeat work` to create organized directories (supports `work .` in 0.5.5)
3. **Batch Upload** - Upload directories recursively with `codebeat upload -R`
4. **Batch Download** - **NEW in 0.5.5**: Download directories recursively with `codebeat download -R`
5. **File Operations** - Upload, download, query, and search documents

## Execution Strategy

**Always follow this interactive approach:**

### Phase 1: Configuration Check (ALWAYS First)

Before ANY file operation, run:
```bash
codebeat status
```

Parse the output to determine configuration state:
- **Token missing**: Guide through `codebeat token` setup
- **Space missing**: Guide through `codebeat space` selection
- **ParentKey missing**: Optional - offer work directory creation
- **Fully configured**: Proceed with file operations

**For detailed configuration guidance**, see [references/configuration-guide.md](references/configuration-guide.md)

### Phase 2: Task Understanding

Determine what the user wants:
- **Upload**: Single file, multiple files, or recursive directory (`-R`)
- **Download**: By title, interactive selection, or recursive directory (`-R`)
- **Query**: List or tree view
- **Organization**: Create workspaces with `codebeat work`

### Phase 3: Command Execution

Execute appropriate commands with clear feedback:
- Use `-i` flag for interactive modes
- Use `-R` flag for recursive operations
- Explain what's happening during execution
- Provide clear success/error feedback

### Phase 4: Verification and Follow-up

After execution:
1. Check output for success/errors
2. Inform user of results with details
3. Suggest follow-up actions if appropriate

## Quick Command Reference

### Configuration
```bash
codebeat setup              # First-time setup wizard
codebeat token              # Configure API token
codebeat space [-l g|p]     # Select space (global/project level)
codebeat status             # View current configuration
```

### Upload Operations
```bash
codebeat upload file.md              # Single file
codebeat upload -i                   # Interactive upload
codebeat upload file.md -p <key>     # To specific parent
codebeat upload file.md -r           # Re-select parent
codebeat upload -R docs/             # Recursive directory upload
```

### Download Operations
```bash
codebeat download "title"            # By title
codebeat download -i                 # Interactive download
codebeat download "title" -o ./dir   # To specific directory
codebeat download -R "目录"          # Recursive download (NEW in 0.5.5)
```

### Workspace Management
```bash
codebeat work tmp/feat-123           # Create workspace
codebeat work .                      # Use current directory (NEW in 0.5.5)
```

### Query Operations
```bash
codebeat list                        # List documents
codebeat tree                        # Show tree structure
codebeat sync                        # Sync from server
```

**For complete command reference**, see [references/command-reference.md](references/command-reference.md)

## Best Practices

### 1. ORGANIZE with work directories
```bash
# Create workspace for organized document management
codebeat work ai-conversations
codebeat work project-docs

# Or use current directory
cd my-project && codebeat work .
```

**Benefits**: Keeps documents organized by topic, maintains clean hierarchy.

### 2. BATCH OPERATIONS for efficiency
```bash
# Upload entire directories
codebeat upload -R ./docs/

# Download entire documentation trees (NEW in 0.5.5)
codebeat download -R "项目文档" -o ./backup/
```

**Benefits**: Preserves directory structure, saves time, ideal for AI-generated content.

### 3. Use project-level configuration for teams
```bash
codebeat space -l p
# Creates .codebeat/config.yaml (can commit to Git)
```

### 4. Check status before operations
```bash
codebeat status  # Verify configuration is correct
```

## Key Features in 0.5.5

### Recursive Directory Download (`-R`)
- Downloads entire directory trees while preserving structure
- Directory documents saved at same level as directories (no path conflicts)
- Creates `.codebeat.local.yaml` in each directory for future sync
- Perfect for backup and cross-machine synchronization

### Work Current Directory (`work .`)
- Initialize current directory as workspace
- Easier setup for existing project directories

**Example**:
```bash
cd my-project
codebeat work .
codebeat upload README.md
```

## Common Workflows

### Workflow 1: Batch organize AI docs
```bash
# 1. Create workspace
codebeat work ai-outputs/chatgpt-sessions

# 2. Save AI content to files
cd ai-outputs/chatgpt-sessions

# 3. Upload all at once
codebeat upload -R .
```

### Workflow 2: Backup documentation (NEW in 0.5.5)
```bash
# Download entire tree from server
codebeat download -R "项目文档" -o ./backup/

# All documents and structure preserved
# Each directory gets .codebeat.local.yaml for sync
```

### Workflow 3: Quick workspace setup (NEW in 0.5.5)
```bash
cd /path/to/my-project
codebeat work .
codebeat upload README.md docs/design.md
```

**For more examples**, see [references/examples.md](references/examples.md)

## Important Notes

### File Requirements
- ✅ Markdown files (`.md`) only
- ✅ UTF-8 encoding
- ❌ Binary files (images, PDFs)
- ❌ Very large files (>10MB)

### Document Management Limitations
⚠️ **CRITICAL RESTRICTIONS**:

1. **No Delete Command**
   - CodeBeat CLI does NOT have a `delete` command
   - Once uploaded, documents **cannot be deleted**
   - Only option is to **overwrite** existing documents
   - Use caution when uploading - documents are permanent

2. **Unique Document Names Required**
   - Documents with the **same name are NOT allowed** in the same space
   - Even if in different directories, duplicate names will cause errors
   - Error message: `错误: failed to upload file. ErrCode:40003,ErrMsg:上传同名文档时不允许移动，只允许覆盖`

3. **Handling Name Conflicts**
   When you encounter the duplicate name error:

   **Option 1: Rename and Re-upload**
   ```bash
   # Rename local file to avoid conflict
   mv API.md API-v2.md
   codebeat upload API-v2.md
   ```

   **Option 2: Overwrite Existing Document**
   ```bash
   # Find existing document location
   codebeat tree | grep "API"

   # Upload to same location to overwrite
   codebeat upload API.md -p <parentKey>
   ```

   **Best Practice**: Use descriptive, unique names with version or context:
   ```bash
   # Good: Unique, descriptive names
   API-UserAuth-v2.md
   Design-PaymentModule.md
   Guide-DockerDeployment.md

   # Avoid: Generic names likely to conflict
   API.md
   README.md
   Guide.md
   ```

### Authentication
- Token required for all operations
- Use `codebeat token` to configure

### Document Hierarchy
- Documents organized in tree structure
- Each document has unique `key` (ID)
- `parentKey` determines location in tree
- Use `codebeat tree` to visualize structure

## Troubleshooting

**Common Issues**:
- **Token not configured**: Run `codebeat token`
- **Space not selected**: Run `codebeat space`
- **Upload to wrong parent**: Use `-r` flag to re-select
- **Download not found**: Use `-i` for interactive selection
- **Recursive upload not preserving structure**: Ensure using `-R` flag
- **⚠️ "同名文档" error**: Document with same name already exists in space - rename file or overwrite
- **⚠️ Cannot delete documents**: CodeBeat has no delete command - documents are permanent

**For complete troubleshooting guide**, see [references/troubleshooting.md](references/troubleshooting.md)

## Need More Details?

- **Configuration Guide**: [references/configuration-guide.md](references/configuration-guide.md)
- **Command Reference**: [references/command-reference.md](references/command-reference.md)
- **Examples**: [references/examples.md](references/examples.md)
- **Troubleshooting**: [references/troubleshooting.md](references/troubleshooting.md)

---

**Remember**: Always check configuration with `codebeat status` first, use interactive modes when users need guidance, and suggest best practices for organization.
