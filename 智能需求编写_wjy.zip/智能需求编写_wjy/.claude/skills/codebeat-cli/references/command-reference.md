# Complete Command Reference

## Configuration Commands

### Setup initialization
```bash
codebeat setup
```
Interactive setup wizard for first-time users. Configures token and space.

### Token management
```bash
codebeat token
```
Set or update API access token.

### Space selection
```bash
codebeat space                    # Interactive selection
codebeat space -l p               # Set project-level space (can commit to Git)
codebeat space -l g               # Set global-level space
```

### View status
```bash
codebeat status
```
Shows current configuration, token status, space info, and file paths.

---

## File Upload Commands

### Upload single file
```bash
codebeat upload README.md
codebeat up README.md              # Using alias
```

### Interactive upload
```bash
codebeat upload -i
```
Guided upload with file selection and parent node selection.

### Upload with parent node
```bash
codebeat upload API.md -p 1234567890
```
Upload to a specific parent document node.

### Re-select parent node
```bash
codebeat upload API.md -r         # or --root
```
Ignore current parentKey and re-enter interactive parent selection.

### Batch upload (multiple files)
```bash
codebeat upload file1.md file2.md file3.md
```

### Recursive directory upload
```bash
codebeat upload -R docs/          # Upload all .md files in docs/ recursively
```

**IMPORTANT for Batch Operations:**
- `-R` flag enables recursive upload
- Automatically creates folder nodes on server to match your local directory structure
- Perfect for organizing AI-generated documentation by topic/feature
- Example: If you have `docs/api/endpoints.md` and `docs/guides/tutorial.md`, both the folder structure and files will be created on server

**Common Batch Upload Patterns:**
```bash
# Upload all documentation in a project
codebeat upload -R ./docs/

# Upload AI conversation outputs organized by date
codebeat upload -R ./ai-outputs/

# Upload entire wiki structure
codebeat upload -R ./wiki/
```

---

## File Download Commands

### Download by title
```bash
codebeat download "API文档"
codebeat down "API文档"            # Using alias
```

### Download to specific directory
```bash
codebeat download "API文档" -o ./docs
```

### Interactive download
```bash
codebeat download -i
```
Select document from interactive list.

### Recursive directory download (NEW in 0.5.5)
```bash
codebeat download -R "文档目录"     # Download all documents in directory recursively
codebeat download -R "文档目录" -o ./output  # Download to specific output directory
```

**IMPORTANT for Recursive Download:**
- `-R` flag enables recursive download
- Automatically creates local directories to match server structure
- Downloads directory document files to the same level as directories (not inside them)
- Each directory gets a `.codebeat.local.yaml` configuration file for future sync
- Perfect for backing up entire documentation trees or syncing between machines

**How Directory Document Files are Handled:**
- Server: `wiki/tmp.md` (directory document) + `wiki/tmp/doc1.md` (sub-document)
- Local: `wiki/tmp.md` + `wiki/tmp/doc1.md` (directory document saved at same level as tmp/ folder)
- This avoids path conflicts and maintains clear structure

**Common Recursive Download Patterns:**
```bash
# Download entire documentation tree
codebeat download -R "项目文档"

# Download to specific output directory
codebeat download -R "API文档" -o ./docs/

# Download workspace directory
codebeat download -R "ai-conversations" -o ./backup/
```

---

## File Query Commands

### List documents
```bash
codebeat list                      # or codebeat ls
```
Shows documents in current space/parent node.

### Tree view
```bash
codebeat tree
```
Shows hierarchical tree structure of documents.

---

## File Sync Commands

### Sync documents
```bash
codebeat sync
```
Pull latest content from server for documents in current directory.

---

## Workspace Commands

### Initialize working directory
```bash
codebeat work tmp/feat-12345
```

### Initialize current directory as workspace (NEW in 0.5.5)
```bash
codebeat work .
```
Creates a workspace in the current directory (if not root path).

**RECOMMENDED for Organized Document Management:**
- Creates a local working directory AND a corresponding document node on the server
- All files uploaded from this directory automatically become children of this node
- Perfect for organizing AI-generated docs by feature, project, or topic
- Helps maintain clean document hierarchy
- `work .` allows initializing current directory as workspace

**Common Use Cases:**
```bash
# Create workspace for a feature
codebeat work tmp/feat-user-auth

# Use current directory as workspace
cd my-project
codebeat work .

# Create workspace for API documentation
codebeat work docs/api

# Create workspace for AI-generated content
codebeat work ai-outputs/chatgpt-conversations

# After creating workspace, upload files normally
cd tmp/feat-user-auth
codebeat upload design.md
codebeat upload implementation.md
# Both files will be organized under the feat-user-auth node
```

---

## Command Aliases

- `upload` → `up`
- `download` → `down`
- `list` → `ls`

---

## Global Flags

These flags work with all commands:

```bash
-s, --space string   文档空间编码
-v, --verbose        详细输出
```
