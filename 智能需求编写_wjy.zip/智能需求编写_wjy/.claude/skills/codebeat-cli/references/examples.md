# Examples and Use Cases

## Common Scenarios

### Example 1: First-time setup
```bash
# 1. Initialize configuration
codebeat setup

# 2. Verify setup
codebeat status

# 3. Upload first document
codebeat upload README.md
```

### Example 2: Team collaboration
```bash
# 1. Set project-level space (shareable via Git)
codebeat space -l p

# 2. Team member uploads document
codebeat upload architecture.md

# 3. Other members download
codebeat download "架构设计"

# 4. Sync latest changes
codebeat sync
```

### Example 3: Feature branch work
```bash
# 1. Create working directory for feature
codebeat work tmp/feat-12345

# 2. Upload related documents
cd tmp/feat-12345
codebeat upload api-design.md
codebeat upload implementation.md

# Documents are automatically organized under feat-12345 node
```

### Example 4: Batch organize AI-generated docs
```bash
# 1. Create directory for AI outputs
mkdir -p ai-docs

# 2. Save AI-generated content to markdown files
# (or copy from Claude/ChatGPT conversations)

# 3. Upload all at once
codebeat upload -R ai-docs/
```

### Example 5: Backup and sync documentation (NEW in 0.5.5)
```bash
# 1. Download entire documentation tree from server
codebeat download -R "项目文档" -o ./backup/

# 2. All documents and directory structure are preserved
# Each directory gets .codebeat.local.yaml for future sync

# 3. Sync between machines
# On Machine A: Upload docs
codebeat upload -R ./project-docs/

# On Machine B: Download the same structure
codebeat download -R "project-docs" -o ./
```

### Example 6: Quick workspace setup (NEW in 0.5.5)
```bash
# 1. Navigate to your existing project directory
cd /path/to/my-project

# 2. Initialize current directory as workspace
codebeat work .

# 3. Upload project documentation
codebeat upload README.md
codebeat upload docs/design.md
codebeat upload docs/api-guide.md
```

---

## Interactive Configuration Examples

### Example: User says "配置 CodeBeat"

**Your Actions:**
1. Run: `codebeat status`
   → Check current configuration state

2. Analyze output:
   - **Scenario A**: Not configured at all
     → "I see CodeBeat CLI hasn't been configured yet. Let me help you set it up."

   - **Scenario B**: Partially configured (token exists, no space)
     → "Your token is configured, but we need to select a workspace."

   - **Scenario C**: Fully configured
     → "CodeBeat is already configured. Here's your current setup:
        Token: ✅ Set
        Space: AI(开发环境) ✅
        Would you like to modify anything?"

3. Interactive Configuration Flow:

   **If token not set:**
   → Ask: "Would you like to configure your API token now?"
      - Yes → Run: `codebeat token`
      - No → "You can configure later when needed"

   **If space not set:**
   → Ask: "Which configuration level do you prefer?"
      1. Global (personal, applies to all projects)
      2. Project-level (team-shared, can commit to Git)
      → Run: `codebeat space -l g` (or `-l p`)

   **If parentKey not set:**
   → Ask: "Would you like to organize uploads under a parent node?"
      - Yes → "You can create a work directory with 'codebeat work <dir>'"
      - No → "Files will upload to root level"

4. Verify configuration:
   → Run: `codebeat status`
   → "✅ Configuration complete! Your setup:
      - Token: ak_20309... ✅
      - Space: AI(开发环境) (dev-ai) ✅
      - Ready to upload files!"

5. Offer next steps:
   → "You can now:
      - Upload files: codebeat upload <file>
      - Create work directory: codebeat work <dir>
      - View available commands: codebeat --help"

---

## Batch Download Examples (NEW in 0.5.5)

### Example: User wants to download entire directory

**User**: "我想下载整个项目文档目录"

**Your Actions:**
1. Run: `codebeat status` (verify configuration)

2. Check if configured:
   → If configured: Continue to step 3
   → If not configured: Follow configuration process

3. Understand the requirement:
   → "You want to download the entire '项目文档' directory recursively.
      This will download all documents and subdirectories while preserving the structure."

   → "Where would you like to save it? (default: current directory)"

   User: `./backup/`

4. Execute recursive download:
   → Run: `codebeat download -R "项目文档" -o ./backup/`

5. Report results:
   → "✅ Download complete! Directory structure:
      ./backup/项目文档/
        ├── .codebeat.local.yaml
        ├── API文档/
        │   ├── .codebeat.local.yaml
        │   ├── overview.md
        │   └── reference.md
        ├── 设计文档/
        │   ├── .codebeat.local.yaml
        │   └── architecture.md
        └── 项目文档.md (directory document at same level as 项目文档/ folder)

      All documents and directory structure have been preserved!"

6. Follow-up:
   → "You can sync updates later with 'codebeat sync' or download other directories."

---

## Work Directory Examples (NEW in 0.5.5)

### Example: User wants to use current directory as workspace

**User**: "我想在当前项目目录下管理文档"

**Your Actions:**
1. Run: `codebeat status` (check configuration)

2. If configured:
   → "Perfect! I'll create a workspace in your current directory."

   → Run: `codebeat work .`

   → "✅ Workspace created! Current directory is now a CodeBeat workspace."

3. Guide next steps:
   → "You can now upload files from this directory:"
      - `codebeat upload README.md`
      - `codebeat upload docs/*.md`
      - `codebeat upload -R ./docs/` (recursive upload)

   → "All uploaded files will be organized under this workspace node."

4. Example upload:
   User: "上传这个设计文档"

   → Run: `codebeat upload design.md`
   → "✅ Uploaded! Document is now organized under your workspace."

---

## Handling Document Name Conflicts

### Scenario 1: Upload fails with "同名文档" error

**Error message**: `错误: failed to upload file. ErrCode:40003,ErrMsg:上传同名文档时不允许移动，只允许覆盖`

**What happened**: You tried to upload a document with a name that already exists in the space.

**Solution 1: Rename and upload**
```bash
# Step 1: Check what documents exist
codebeat list | grep -i api

# Step 2: Rename your local file
mv API.md API-Enhanced.md

# Step 3: Upload with new name
codebeat upload API-Enhanced.md
```

**Solution 2: Find and overwrite**
```bash
# Step 1: Find the existing document
codebeat tree | grep "API"

# Step 2: Get its parent key and overwrite
codebeat upload API.md -p <existingParentKey>
```

**Solution 3: Use interactive mode**
```bash
# Re-select parent to overwrite
codebeat upload API.md -r
```

### Scenario 2: Organizing multiple API documents

**Problem**: You have several API documents with the same generic name.

**Best Practice: Use descriptive naming**
```bash
# ❌ Bad: Generic names will conflict
API.md
README.md
Design.md

# ✅ Good: Descriptive names avoid conflicts
API-UserAuthentication-v2.md
README-PaymentGateway.md
Design-NotificationService.md
```

**Example workflow**:
```bash
# 1. Organize by feature
codebeat work project/api

# 2. Upload with descriptive names
cd project/api
codebeat upload API-UserAuth.md
codebeat upload API-Payment.md
codebeat upload API-Notification.md

# 3. No conflicts because names are unique!
```

---

## Understanding Document Permanence

### Critical Limitation: No Delete Command

**Important**: CodeBeat CLI does NOT have a delete command. Once uploaded, documents are permanent.

**What this means**:
- ❌ Cannot remove documents from server
- ❌ Cannot "undo" an upload
- ✅ Can only overwrite existing documents
- ✅ Must plan structure carefully

### Best Practices for Permanent Documents

**Strategy 1: Test in test space first**
```bash
# Create test space
codebeat space
# Select "test-environment"

# Test your uploads
codebeat upload test-doc.md

# Verify structure
codebeat tree

# When satisfied, switch to production space
codebeat space
# Select "production"
```

**Strategy 2: Use "deprecated" markers**
```bash
# Old document needs to be removed
# Instead of deleting (impossible), mark as deprecated

echo "# DEPRECATED\n\nThis document is no longer maintained.\nSee: new-api-doc.md" > old-api.md

# Overwrite with deprecation notice
codebeat upload old-api.md -r
```

**Strategy 3: Organize in archive folders**
```bash
# Create archive structure
codebeat work archive/2025

# Move old content there
cd archive/2025
codebeat upload old-design.md
codebeat upload old-api-spec.md
```

### Example: Careful planning workflow

```bash
# 1. Plan your structure locally first
mkdir -p docs/{api,guides,design}
touch docs/api/{auth,payment,notification}.md
touch docs/guides/{quickstart,deployment}.md
touch docs/design/{architecture,database}.md

# 2. Review structure
tree docs/

# 3. Use descriptive names to avoid conflicts
# api-auth.md instead of auth.md
# guides-quickstart.md instead of quickstart.md

# 4. Test upload in test space
codebeat space  # Select test space
codebeat upload -R docs/

# 5. Verify
codebeat tree

# 6. When happy, switch to production
codebeat space  # Select production
codebeat upload -R docs/
```

---

## AI Content Management Examples

### Example: Managing ChatGPT conversations

```bash
# 1. Create workspace for ChatGPT outputs
codebeat work ai-outputs/chatgpt-sessions

# 2. Organize locally
cd ai-outputs/chatgpt-sessions
mkdir -p api-design code-review tutorials

# 3. Save conversations to respective folders
# (Copy ChatGPT outputs to markdown files)

# 4. Upload organized structure
codebeat upload -R .

# Result: Entire conversation hierarchy preserved on server
```

### Example: Managing Claude conversation history

```bash
# 1. Create workspace for Claude conversations
codebeat work claude-conversations

# 2. Upload existing conversation markdown files
cd claude-conversations
codebeat upload -R ./history/

# 3. Download on another machine
codebeat download -R "claude-conversations" -o ./
```
