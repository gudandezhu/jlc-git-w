# Troubleshooting Guide

## Common Issues and Solutions

### Issue 1: Token not configured

**Error**: `未配置 doc token，请运行: codebeat token`

**Solution**:
```bash
codebeat token
# Enter your API token when prompted
```

---

### Issue 2: Space not selected

**Error**: `文档空间编码未设置`

**Solution**:
```bash
codebeat space
# Select from available spaces
```

---

### Issue 3: Upload to wrong parent

**Problem**: File uploaded to wrong location

**Solution**:
```bash
# Re-upload with parent selection
codebeat upload file.md -r

# Or specify parentKey explicitly
codebeat upload file.md -p 1234567890
```

---

### Issue 4: Download fails with "not found"

**Possible causes**:
- Title mismatch (use exact title)
- File in different space
- Case sensitivity

**Solution**:
```bash
# Use interactive download to find file
codebeat download -i

# Or list files to see available titles
codebeat list
```

---

### Issue 5: Recursive upload not preserving structure

**Problem**: Folder hierarchy not created on server

**Solution**:
```bash
# Make sure to use -R flag
codebeat upload -R docs/

# Not just:
codebeat upload docs/  # This won't preserve structure
```

---

### Issue 6: Upload fails with "同名文档" error

**Error**: `错误: failed to upload file. ErrCode:40003,ErrMsg:上传同名文档时不允许移动，只允许覆盖`

**Translation**: "Error: Uploading documents with the same name does not allow moving, only overwriting"

**Root Cause**:
- CodeBeat **does not allow documents with the same name** in the same space
- This is a **space-level restriction**, not directory-level
- Even if documents are in different directories, duplicate names will cause errors

**Why This Happens**:
```
Space: "MyProject"
├── docs/
│   └── API.md          ← Existing document
└── guides/
    └── API.md          ← ERROR: Cannot upload - name "API.md" already exists
```

**Solutions**:

**Option 1: Rename local file and re-upload**
```bash
# Check what documents exist
codebeat list | grep -i api

# Rename your local file to avoid conflict
mv API.md API-NewFeature.md

# Upload with new name
codebeat upload API-NewFeature.md
```

**Option 2: Overwrite existing document**
```bash
# Find the existing document's parent key
codebeat tree | grep "API.md"

# Upload to same location to overwrite
codebeat upload API.md -p <existingParentKey>

# Or use -r to re-select parent interactively
codebeat upload API.md -r
```

**Option 3: Use descriptive, unique names**
```bash
# Good practice: Include context in filenames
API-UserAuthentication.md
API-PaymentGateway.md
API-NotificationService.md

# Avoid: Generic names likely to conflict
API.md
README.md
Design.md
```

**Prevention Strategies**:
1. **Use descriptive names**: Include project, module, or version in filename
2. **Check before upload**: `codebeat list` to see existing documents
3. **Use tree view**: `codebeat tree` to visualize structure
4. **Establish naming conventions**: Standard prefixes/suffixes for your team

**Important Notes**:
- ⚠️ This restriction applies to the **entire space**, not just a directory
- ⚠️ Document titles (filenames) must be unique across all documents
- ⚠️ CodeBeat uses document title as a unique identifier

---

### Issue 7: Cannot delete uploaded documents

**Critical Limitation**: CodeBeat CLI **does NOT have a delete command**

**What This Means**:
- ✅ Once uploaded, documents **cannot be deleted**
- ✅ Only option is to **overwrite** existing documents
- ✅ Documents are **permanent** in the system

**Workaround Strategies**:

**Strategy 1: Overwrite with updated content**
```bash
# Simply upload again to the same location
codebeat upload outdated-doc.md -p <parentKey>
```

**Strategy 2: Move content to new document (if you want to "delete")**
```bash
# 1. Upload new version with different name
mv old-doc.md new-doc.md
codebeat upload new-doc.md

# 2. Overwrite old document with deprecation notice
echo "# Deprecated\n\nThis document has been replaced by new-doc.md" > old-doc.md
codebeat upload old-doc.md -p <parentKey>
```

**Strategy 3: Organize in "Archive" folder**
```bash
# Create archive folder
codebeat work archive/deprecated

# Upload replacement there
cd archive/deprecated
codebeat upload old-content.md
```

**Best Practices to Avoid Issues**:
1. **Test before production**: Use a test space first
2. **Use descriptive names**: Avoid generic names you might want to delete later
3. **Plan structure carefully**: Think about long-term organization
4. **Keep backups locally**: Always have local copies

**Important**:
- ⚠️ Always verify before uploading - there's no undo
- ⚠️ Use `-i` flag for interactive mode to confirm uploads
- ⚠️ Consider using a test space for experimentation

---

### Issue 8: Recursive download has missing files

**Problem**: Some files not downloaded

**Solutions**:
1. **Check permissions**: Ensure you have read access to all documents
2. **Check network**: Verify stable internet connection
3. **Use verbose mode**: Add `-v` flag to see detailed logs
   ```bash
   codebeat download -R "目录名" -v
   ```
4. **Check server structure**: Some documents might be in different parent nodes

---

### Issue 7: Directory documents in wrong location (0.5.5)

**Problem**: Directory document files (.md) saved in wrong place

**Explanation**: In version 0.5.5, directory documents are saved at the same level as the directory folder, not inside it.

**Example**:
```
Server:                    Local (correct):
wiki/                      wiki/
├── tmp/                   ├── tmp/
│   └── doc.md             │   └── doc.md
└── tmp.md                 └── tmp.md  (same level as tmp/ folder)
```

This is intentional to avoid path conflicts.

---

### Issue 9: work . command fails

**Error**: `work . 命令失败`

**Possible causes**:
- Current directory is root path (`/` or `C:\`)
- No write permissions
- Invalid directory name

**Solution**:
1. Navigate to a non-root directory:
   ```bash
   cd /path/to/your/project
   codebeat work .
   ```
2. Check write permissions:
   ```bash
   ls -la .
   ```
3. Use absolute path instead:
   ```bash
   codebeat work /path/to/project
   ```

---

### Issue 10: Configuration conflicts

**Problem**: Multiple config files causing unexpected behavior

**Explanation**: CodeBeat uses three config levels with priority:
```
Directory > Project > Global
```

**Solution**:
1. Check all config files:
   ```bash
   codebeat status
   ```
2. Remove conflicting config:
   ```bash
   # Remove directory-level config
   rm .codebeat.local.yaml

   # Or remove project-level config
   rm .codebeat/config.yaml
   ```
3. Re-configure as needed

---

### Issue 11: Sync fails or overwrites changes

**Problem**: `codebeat sync` causes conflicts

**Explanation**: Sync pulls server content and may overwrite local changes

**Best practices**:
1. **Commit local changes first**: Upload before syncing
   ```bash
   codebeat upload modified-file.md
   codebeat sync
   ```
2. **Use version control**: Keep Git history
3. **Backup before sync**:
   ```bash
   cp -r ./docs ./docs-backup
   codebeat sync
   ```

---

## Debug Mode

When troubleshooting, use verbose mode for detailed logs:

```bash
# Verbose upload
codebeat upload file.md -v

# Verbose download
codebeat download "文档" -v

# Verbose recursive download
codebeat download -R "目录" -v
```

---

## Getting Help

If issues persist:

1. **Check version**:
   ```bash
   codebeat version
   ```

2. **Review status**:
   ```bash
   codebeat status
   ```

3. **Check configuration files**:
   ```bash
   # Global config
   cat ~/.codebeat/cli/config.yaml

   # Project config
   cat .codebeat/config.yaml

   # Directory config
   cat .codebeat.local.yaml
   ```

4. **Test with minimal setup**:
   ```bash
   # Create test workspace
   codebeat work tmp/test

   # Upload test file
   cd tmp/test
   echo "# Test" > test.md
   codebeat upload test.md

   # Download test file
   codebeat download "test"
   ```

---

## File Requirements

**Supported formats**:
- ✅ Markdown files (`.md`)
- ❌ Binary files (images, PDFs)
- ❌ Very large files (>10MB)

**Encoding**:
- ✅ UTF-8
- ❌ Other encodings (may cause issues)

**Authentication**:
- Token required for all operations
- Token stored encrypted in local keychain
- Use `codebeat token` to configure or update
