# Complete Configuration Guide

This guide provides detailed instructions for configuring CodeBeat CLI.

## Configuration System Overview

CodeBeat uses a three-level configuration system:

### 1. Global Configuration
- **Path**: `~/.codebeat/cli/config.yaml`
- **Scope**: Personal default settings
- **Use case**: Default token and space for all projects

### 2. Project Configuration
- **Path**: `.codebeat/config.yaml` (in project root)
- **Scope**: Team-shared settings
- **Use case**: Can commit to Git for team collaboration
- **Priority**: Higher than global

### 3. Directory Configuration
- **Path**: `.codebeat.local.yaml`
- **Scope**: Temporary override for specific directory
- **Use case**: Working on specific feature/docs
- **Priority**: Highest (overrides project and global)

### Configuration Priority
```
Directory config > Project config > Global config
```

---

## Interactive Configuration Process

### Step 1: Check Current Configuration Status

Before guiding users through configuration, ALWAYS check the current state:

```bash
codebeat status
```

This command shows:
- Token status (configured or not)
- Current space (SpaceCode, SpaceLabel, SpaceKey)
- Current parentKey (if set)
- Configuration file locations
- Which configuration levels exist (global/project/directory)

### Step 2: Analyze Configuration State

Based on the `codebeat status` output, determine what needs to be configured:

**Scenario A: No Token**
```
Token       : (未设置)
```
→ User needs to set token first using `codebeat token`

**Scenario B: Token Exists, No Space**
```
Token       : ak_20309...
SpaceLabel  : (未设置)
SpaceCode   : (未设置)
```
→ User needs to select space using `codebeat space`

**Scenario C: Token and Space Exist, No ParentKey**
```
Token       : ak_20309...
SpaceLabel  : AI(开发环境)
ParentKey   : (未设置)
```
→ Optional: User can set parentKey for organized uploads

**Scenario D: Fully Configured**
```
Token       : ak_20309...
SpaceLabel  : AI(开发环境)
ParentKey   : 1234567890
```
→ Configuration complete, ready for file operations

### Step 3: Interactive Configuration Flow

**Always ask for user preference before making changes:**

#### For Token Configuration:

If token is not configured, ask:
> "I noticed you haven't configured your API token yet. Would you like to:"
> 1. Set up token now (I'll guide you through interactive setup)
> 2. Skip for now (you can configure later with `codebeat token`)

**Execute based on user choice:**
- If option 1: Run `codebeat token` and guide user through input
- If option 2: Acknowledge and remind about configuration requirement when needed

#### For Space Configuration:

If token exists but space is not selected, ask:
> "Your token is configured, but no workspace (space) is selected. Would you like to:"
> 1. Select a space now (I'll show you available spaces)
> 2. Configure space level (global for all projects, or project-level for team sharing)
> 3. Skip for now

**Execute based on user choice:**
- If option 1: Run `codebeat space` or `codebeat space -l [g|p]`
- If option 2: Explain difference between global (-l g) and project (-l p) level
- If option 3: Acknowledge and continue

#### For ParentKey Configuration:

If token and space exist but parentKey is not set, ask:
> "You're ready to upload files! Optionally, you can set a parent document node to organize your uploads. Would you like to:"
> 1. Set parent node (useful for organizing files under a specific folder)
> 2. Create a work directory (creates both local folder and server node)
> 3. Continue without parentKey (files will upload to root)

**Execute based on user choice:**
- If option 1: Run `codebeat upload <file> -r` to select parent interactively
- If option 2: Run `codebeat work <directory>` to create work directory
- If option 3: Continue with file operations

#### For Reconfiguration:

If user wants to change existing configuration, ask:
> "Your current configuration:"
> - Token: ✅ Configured
> - Space: AI(开发环境) (dev-ai)
> - ParentKey: (not set)
>
> "What would you like to modify?"
> 1. Change token
> 2. Change space
> 3. Set/change parentKey
> 4. View configuration details
> 5. Cancel

**Execute based on user choice:**
- Option 1: `codebeat token`
- Option 2: `codebeat space` or `codebeat space -l [g|p]`
- Option 3: `codebeat work <dir>` or upload with `-r` flag
- Option 4: `codebeat status` (detailed view)
- Option 5: Exit configuration

### Step 4: Verify Configuration

After any configuration change, ALWAYS run:

```bash
codebeat status
```

And inform the user:
> "✅ Configuration updated! Your current setup:"
> - Token: [status]
> - Space: [space name]
> - ParentKey: [if set]
> - Config files: [which ones exist]

### Configuration Decision Tree

```
User needs CodeBeat
    ↓
Run: codebeat status
    ↓
Token configured?
    ├─ No → Guide through `codebeat token`
    │        ↓
    │      Ask: "Set up token now?"
    │        ├─ Yes → Run interactive setup
    │        └─ No → Remind later
    │
    └─ Yes → Space configured?
              ├─ No → Guide through `codebeat space`
              │        ↓
              │      Ask: "Select space now? Which level?"
              │        ├─ Global → `codebeat space -l g`
              │        ├─ Project → `codebeat space -l p`
              │        └─ Skip → Remind later
              │
              └─ Yes → ParentKey set?
                        ├─ No → Ask: "Set parent or create work dir?"
                        │        ├─ Parent → Use `-r` flag on upload
                        │        ├─ Work dir → `codebeat work <dir>`
                        │        └─ Skip → Upload to root
                        │
                        └─ Yes → Ready for file operations!
```

### Important Notes

1. **Always check status first** - Never assume configuration state
2. **Ask before changing** - Give users options, don't auto-configure
3. **Explain the impact** - Tell users what each choice means
4. **Verify after changes** - Confirm configuration was successful
5. **Provide flexibility** - Allow users to skip or defer configuration

### Example Interaction

**User**: "Help me upload a file"

**You**:
1. Run `codebeat status` (check current state)
2. If not configured:
   > "I see you haven't configured CodeBeat yet. Let me help you set it up first."
   >
   > "Would you like to: 1) Configure now, 2) Skip for now?"
3. If configured:
   > "Great! CodeBeat is configured. Ready to upload your file."
   >
   > "Which file would you like to upload?"
