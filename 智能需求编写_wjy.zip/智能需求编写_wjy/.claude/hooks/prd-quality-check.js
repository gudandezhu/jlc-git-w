#!/usr/bin/env node
/**
 * PRD Quality Check Hook
 * 当 07-需求文档自审.md 被创建/编辑时执行质量检查
 */
const fs = require('fs');
const path = require('path');

/**
 * 递归查找文件
 */
function findFile(startDir, filename) {
    const files = fs.readdirSync(startDir);
    for (const file of files) {
        const fullPath = path.join(startDir, file);
        const stat = fs.statSync(fullPath);
        if (stat.isDirectory()) {
            const result = findFile(fullPath, filename);
            if (result) return result;
        } else if (file === filename) {
            return fullPath;
        }
    }
    return null;
}

/**
 * 从功能范围文件中提取功能清单
 */
function extractFeaturesFromScope(content) {
    const features = [];
    const lines = content.split('\n');
    let inFeatureList = false;

    for (const line of lines) {
        const trimmed = line.trim();
        if (trimmed.includes('功能清单') || trimmed.includes('功能列表')) {
            inFeatureList = true;
            continue;
        }
        if (inFeatureList && trimmed.startsWith('-')) {
            features.push(trimmed.substring(1).trim());
        } else if (inFeatureList && trimmed.startsWith('#')) {
            break;
        }
    }
    return features;
}

/**
 * 从PRD中提取功能描述
 */
function extractFeaturesFromPRD(content) {
    const features = [];
    const lines = content.split('\n');
    let inFunctionSection = false;

    for (const line of lines) {
        const trimmed = line.trim();
        if (trimmed.includes('功能') && (trimmed.includes('需求') || trimmed.includes('描述'))) {
            inFunctionSection = true;
            continue;
        }
        if (inFunctionSection && /^[\d\-\*]/.test(trimmed)) {
            features.push(trimmed);
        } else if (inFunctionSection && trimmed.startsWith('#') && !trimmed.includes('功能')) {
            break;
        }
    }
    return features;
}

/**
 * 检查测试覆盖率
 */
function checkTestCoverage(content, hasPrototype) {
    const testKeywords = ['测试', '验证', '验收标准', '测试用例'];
    let score = 0;

    for (const keyword of testKeywords) {
        if (content.includes(keyword)) {
            score += 20;
        }
    }

    if (hasPrototype) {
        score += 10;
    }

    return Math.min(score, 100);
}

/**
 * 主函数
 */
function main() {
    // 从 stdin 读取 hook 数据
    let inputData = {};
    try {
        const stdin = fs.readFileSync(0, 'utf-8');
        if (stdin.trim()) {
            inputData = JSON.parse(stdin);
        }
    } catch (e) {
        // 忽略输入错误
    }

    const projectDir = inputData.project_dir || process.cwd();

    // 检查目标文件是否存在
    const targetFile = findFile(projectDir, '07-需求文档自审.md');

    if (!targetFile) {
        process.exit(0); // 文件不存在，退出
    }

    // 查找相关文件
    const baseDir = path.dirname(targetFile);
    const scopeFile = path.join(baseDir, '02-功能范围.md');
    const prdFile = path.join(baseDir, '05-产品需求文档.md');
    const prototypeFile = path.join(baseDir, '06-原型设计.html');

    // 读取文件内容
    let scopeContent = null;
    let prdContent = null;

    try {
        if (fs.existsSync(scopeFile)) {
            scopeContent = fs.readFileSync(scopeFile, 'utf-8');
        }
        if (fs.existsSync(prdFile)) {
            prdContent = fs.readFileSync(prdFile, 'utf-8');
        }
    } catch (e) {
        console.error('读取文件失败:', e.message);
        process.exit(1);
    }

    // 执行检查
    console.log('\n' + '='.repeat(60));
    console.log('🔍 PRD 质量检查');
    console.log('='.repeat(60));

    if (!scopeContent || !prdContent) {
        console.log('\n⚠️  PRD 质量检查');
        console.log('='.repeat(60));
        console.log('缺少必要的文件，无法执行完整检查：');
        if (!scopeContent) {
            console.log('  ❌ 02-功能范围.md 未找到');
        }
        if (!prdContent) {
            console.log('  ❌ 05-产品需求文档.md 未找到');
        }
        console.log('='.repeat(60) + '\n');
        process.exit(0);
    }

    // 检查1: 功能清单完整性
    console.log('\n📋 检查1: 功能清单完整性');
    const scopeFeatures = extractFeaturesFromScope(scopeContent);
    const prdFeatures = extractFeaturesFromPRD(prdContent);

    let coverageRate = 100;
    if (scopeFeatures.length > 0) {
        let coverage = 0;
        for (const sf of scopeFeatures) {
            const found = prdFeatures.some(pf => pf.includes(sf.substring(0, 30)));
            if (found) coverage++;
        }
        coverageRate = (coverage / scopeFeatures.length) * 100;

        console.log(`  功能范围定义: ${scopeFeatures.length} 项`);
        console.log(`  PRD中已覆盖: ${coverage} 项`);
        console.log(`  覆盖率: ${coverageRate.toFixed(1)}%`);

        if (coverageRate < 100) {
            console.log(`  ⚠️  缺失功能:`);
            for (const f of scopeFeatures) {
                const found = prdFeatures.some(pf => pf.includes(f.substring(0, 30)));
                if (!found) {
                    console.log(`    - ${f}`);
                }
            }
        }
    } else {
        console.log('  ⚠️  无法从功能范围文件中提取功能清单');
    }

    // 检查2: 测试覆盖率
    console.log('\n🧪 检查2: 测试覆盖率');
    const hasPrototype = fs.existsSync(prototypeFile);
    const testCoverage = checkTestCoverage(prdContent, hasPrototype);

    console.log(`  测试覆盖率: ${testCoverage}%`);
    if (hasPrototype) {
        console.log(`  ✓ 检测到原型文件`);
    } else {
        console.log(`  ℹ️  未检测到原型文件`);
    }

    // 总体评估
    console.log('\n' + '='.repeat(60));
    if (coverageRate >= 100 && testCoverage >= 90) {
        console.log('✅ 质量检查通过！');
        console.log('   ✓ 功能清单覆盖率: 100%');
        console.log(`   ✓ 测试覆盖率: ${testCoverage}%`);
    } else {
        console.log('⚠️  质量检查发现问题：');
        console.log(`   - 功能覆盖率: ${coverageRate.toFixed(1)}% ${coverageRate >= 100 ? '✓' : '❌'}`);
        console.log(`   - 测试覆盖率: ${testCoverage}% ${testCoverage >= 90 ? '✓' : '❌'}`);

        if (coverageRate < 100 || testCoverage < 90) {
            console.log('\n💡 改进建议：');
            if (coverageRate < 100) {
                console.log('   - 补充缺失功能的详细描述');
            }
            if (testCoverage < 90) {
                console.log('   - 增加测试用例和验收标准');
                console.log('   - 添加原型设计以提升测试覆盖率');
            }
        }
    }
    console.log('='.repeat(60) + '\n');

    process.exit(0);
}

main();
