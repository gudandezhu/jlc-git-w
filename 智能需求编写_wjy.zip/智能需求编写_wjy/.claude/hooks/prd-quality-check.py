#!/usr/bin/env python3
"""
PRD Quality Check Hook
当 07-需求文档自审.md 被创建/编辑时执行质量检查
"""
import json
import sys
import os
import glob

def check_file_exists(filepath):
    """检查文件是否存在"""
    return os.path.exists(filepath)

def read_file_content(filepath):
    """读取文件内容"""
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            return f.read()
    except Exception as e:
        return None

def extract_features_from_scope(scope_content):
    """从功能范围文件中提取功能清单"""
    features = []
    in_feature_list = False

    for line in scope_content.split('\n'):
        line = line.strip()
        if '功能清单' in line or '功能列表' in line:
            in_feature_list = True
            continue
        if in_feature_list and line.startswith('-'):
            features.append(line[1:].strip())
        elif in_feature_list and line.startswith('#'):
            break

    return features

def extract_features_from_prd(prd_content):
    """从PRD中提取功能描述"""
    features = []
    in_function_section = False

    for line in prd_content.split('\n'):
        line = line.strip()
        if '功能' in line and ('需求' in line or '描述' in line):
            in_function_section = True
            continue
        if in_function_section and line.startswith(('1.', '2.', '3.', '4.', '5.', '6.', '7.', '8.', '9.', '-', '*')):
            features.append(line)
        elif in_function_section and line.startswith('#') and '功能' not in line:
            break

    return features

def check_test_coverage(prd_content, has_prototype):
    """检查测试覆盖率"""
    # 检查PRD中是否包含测试相关章节
    test_keywords = ['测试', '验证', '验收标准', '测试用例']
    coverage_score = 0

    for keyword in test_keywords:
        if keyword in prd_content:
            coverage_score += 20

    # ��果有原型，加分
    if has_prototype:
        coverage_score += 10

    return min(coverage_score, 100)

def main():
    # 从 stdin 读取 hook 数据
    try:
        input_data = json.load(sys.stdin)
    except:
        # Stop 事件可能没有特定数据
        input_data = {}

    project_dir = input_data.get('project_dir', os.getcwd())

    # 检查目标文件是否存在
    target_file = None
    for root, dirs, files in os.walk(project_dir):
        if '07-需求文档自审.md' in files:
            target_file = os.path.join(root, '07-需求文档自审.md')
            break

    if not target_file:
        sys.exit(0)  # 文件不存在，退出

    # 查找相关文件
    base_dir = os.path.dirname(target_file)
    scope_file = os.path.join(base_dir, '02-功能范围.md')
    prd_file = os.path.join(base_dir, '05-产品需求文档.md')
    prototype_file = os.path.join(base_dir, '06-原型设计.html')

    # 读取文件内容
    scope_content = read_file_content(scope_file)
    prd_content = read_file_content(prd_file)

    if not scope_content or not prd_content:
        print("\n" + "="*60)
        print("⚠️  PRD 质量检查")
        print("="*60)
        print("缺少必要的文件，无法执行完整检查：")
        if not scope_content:
            print("  ❌ 02-功能范围.md 未找到")
        if not prd_content:
            print("  ❌ 05-产品需求文档.md 未找到")
        print("="*60 + "\n")
        sys.exit(0)

    # 执行检查
    print("\n" + "="*60)
    print("🔍 PRD 质量检查")
    print("="*60)

    # 检查1: 功能清单完整性
    print("\n📋 检查1: 功能清单完整性")
    scope_features = extract_features_from_scope(scope_content)
    prd_features = extract_features_from_prd(prd_content)

    if scope_features:
        coverage = len([f for f in scope_features if any(f[:30] in p for p in prd_features)])
        coverage_rate = (coverage / len(scope_features)) * 100 if scope_features else 0
        print(f"  功能范围定义: {len(scope_features)} 项")
        print(f"  PRD中已覆盖: {coverage} 项")
        print(f"  覆盖率: {coverage_rate:.1f}%")

        if coverage_rate < 100:
            print(f"  ⚠️  缺失功能:")
            for f in scope_features:
                if not any(f[:30] in p for p in prd_features):
                    print(f"    - {f}")
    else:
        print("  ⚠️  无法从功能范围文件中提取功能清单")
        coverage_rate = 100  # 默认通过

    # 检查2: 测试覆盖率
    print("\n🧪 检查2: 测试覆���率")
    has_prototype = check_file_exists(prototype_file)
    test_coverage = check_test_coverage(prd_content, has_prototype)

    print(f"  测试覆盖率: {test_coverage}%")
    if has_prototype:
        print(f"  ✓ 检测到原型文件")
    else:
        print(f"  ℹ️  未检测到原型文件")

    # 总体评估
    print("\n" + "="*60)
    if coverage_rate >= 100 and test_coverage >= 90:
        print("✅ 质量检查通过！")
        print("   ✓ 功能清单覆盖率: 100%")
        print(f"   ✓ 测试覆盖率: {test_coverage}%")
    else:
        print("⚠️  质量检查发现问题：")
        print(f"   - 功能覆盖率: {coverage_rate:.1f}% {'✓' if coverage_rate >= 100 else '❌'}")
        print(f"   - 测试覆盖率: {test_coverage}% {'✓' if test_coverage >= 90 else '❌'}")

        if coverage_rate < 100 or test_coverage < 90:
            print("\n💡 改进建议：")
            if coverage_rate < 100:
                print("   - 补充缺失功能的详细描述")
            if test_coverage < 90:
                print("   - 增加测试用例和验收标准")
                print("   - 添加原型设计以提升测试覆盖率")

    print("="*60 + "\n")

    sys.exit(0)

if __name__ == "__main__":
    main()
